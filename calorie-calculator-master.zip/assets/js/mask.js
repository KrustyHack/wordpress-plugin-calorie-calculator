import '/assets/js/lib/input-mask.min.js'

Inputmask().mask(document.querySelectorAll("[data-inputmask]"));